# Educational Microcontroller Simulator with Process Scheduling

## Project Title
Educational Microcontroller Simulator with Process Scheduling

## Problem Objective
Develop a simplified educational microcontroller simulator that demonstrates instruction execution, memory and peripheral operations, and process management. The project integrates Microprocessor Architecture, Data Structures, and Operating Systems concepts into a single working system, helping users visualize how programs execute and how CPU scheduling manages multiple programs.

## Problem Statement
Design and implement a software-based simulator for an 8-bit microcontroller processor. The simulator models the essential processor components, executes a defined subset of instructions, manages program memory, data memory, and stack, and provides simplified GPIO, timer, and interrupt functionality. It also supports multiple programs as processes using appropriate data structures — a Process Control Block (PCB), ready queue, context switching — and implements FCFS, Round Robin, and Priority CPU scheduling algorithms.

## Project Scope
- Simulate a defined subset (~15–20) of instructions for the assigned 8-bit microcontroller.
- Model registers, Program Counter, Stack Pointer, flags, program memory, data memory, and stack.
- Provide simplified GPIO, timer, and interrupt handling.
- Represent multiple loaded programs as OS-level processes (PCB, states, ready queue).
- Implement FCFS, Round Robin, and Priority scheduling with context switching.
- Provide interactive load / run / step / reset operations.
- Report performance metrics: waiting time, turnaround time, response time, context switches, CPU utilization.
- Out of scope: full binary instruction encoding, real hardware timing accuracy, and instructions outside the chosen subset.

## Microcontroller Being Simulated
**Nuvoton MS51FB9AE** — an 8-bit, 1T-enhanced **8051/MCS-51-core** microcontroller (24 MHz, 16 KB Flash/APROM, 1 KB SRAM, 4 KB LDROM for ISP boot code, 18 GPIO, dual DPTR, 4-level priority interrupts, multiple timers, PWM, UART/SPI/I²C, 12-bit ADC).

Since its CPU core is fully compatible with the standard 8051 instruction set, our simulator models the **classic 8051 architecture** at a simplified, educational scale (see `docs/decisions/mcu-study.md` for the full study notes):
- Accumulator (A) and B register
- General-purpose registers R0–R7 (register banks selected via PSW)
- 16-bit Program Counter (PC) and 8-bit Stack Pointer (SP)
- Program Status Word (PSW) flag register: Carry, Auxiliary Carry, Overflow, Parity
- Separate program memory (Flash) and internal data memory (RAM)
- Bit-addressable GPIO ports, hardware timers, and a priority interrupt controller

We are not implementing the full real chip (per project guidelines) — only the subset of registers, instructions, and peripherals needed to demonstrate the simulator's learning goals.

## Team

| Member | GitHub Username | Primary Responsibility | Supporting Responsibility |
|---|---|---|---|
| [Name] — Team Leader | [@username] | CPU & Instruction Execution | Integration & GitHub |
| [Name] | [@username] | Memory & Stack | CPU support |
| [Name] | [@username] | Data Structures & Process Management | Testing |
| [Name] | [@username] | OS Scheduling & Context Switching | UI & Integration |

## Selected Programming Language
**Java** (preferred language per project guidelines — no alternative-language justification required).

- **Advantages for this project:** strong OOP support fits register/CPU/PCB modeling; built-in `Queue`, `Deque`, `PriorityQueue` for scheduler structures; platform-independent; easy to unit test with JUnit; static typing catches state-machine bugs early.
- **Limitations:** more verbose than a scripting language for quick prototyping; GUI (Swing) is dated compared to modern alternatives if a visual UI is attempted.

## Initial System Architecture

This follows the block diagram provided in the Week 1 brief:

```mermaid
flowchart TD
    SIM["MICROCONTROLLER SIMULATOR"]
    CPU["CPU"]
    MEM["MEMORY"]
    PER["PERIPHERALS"]
    GT["GPIO / TIMER"]
    INT["INTERRUPTS"]
    PM["PROCESS MANAGER"]
    SCH["SCHEDULER"]
    UI["USER INTERFACE"]

    SIM --> CPU
    SIM --> MEM
    SIM --> PER
    PER --> GT
    PER --> INT
    MEM --> PM
    PM --> SCH
    SCH --> UI
```

**What each block does:**
- **CPU** — registers, PC, SP, flags, fetch-decode-execute cycle, instruction lookup table
- **MEMORY** — program memory, data memory, stack
- **PERIPHERALS** — GPIO/Timer and Interrupts (simplified I/O and event handling)
- **PROCESS MANAGER** — PCBs, process states, ready queue (built on top of memory, since each process's code/data lives there)
- **SCHEDULER** — FCFS, Round Robin, Priority algorithms, context switching
- **USER INTERFACE** — load / run / step / reset, and visualization of processor + scheduling state

*(This is the Week 1 initial design — it will be refined as the project progresses.)*

## Initial Development Plan
Project duration: **2 months (~8 weeks)**.

| Week | Focus |
|---|---|
| 1 | Team formation, repo setup, MCU architecture study, language finalization |
| 2 | CPU core (registers, PC, SP, flags) + memory model |
| 3 | Instruction set implementation + instruction lookup table |
| 4 | Stack, GPIO, timer, interrupt handling |
| 5 | PCB design + process manager (states, ready queue); begin FCFS scheduling |
| 6 | Round Robin + Priority scheduling, context switching |
| 7 | Performance metrics (waiting/turnaround/response time, CPU utilization) + UI |
| 8 | Integration testing, test programs, documentation, final report |

*(May shift slightly depending on team pace — will be refined week by week.)*

## Repository Structure
```
project-root/
├── README.md
├── .gitignore
├── docs/
│   ├── meetings/
│   ├── decisions/
│   └── weekly-status/
├── src/
├── tests/
└── programs/
```
