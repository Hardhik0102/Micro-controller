# Week 1 Status Report

## Planned Work
- Team formation and GitHub repository setup
- Study assigned microcontroller architecture
- Finalize programming language
- Draft initial simulator architecture
- Divide responsibilities

## Completed Work
- Repository created (public), team leader identified, all members added as collaborators
- README.md with project overview, scope, architecture, and plan
- .gitignore added
- Folder structure created
- Language finalized: Java
- Initial architecture diagram drafted (see README)

## Pending Work
- Detailed CPU register/flag design
- Instruction-set analysis document
- Data-structure design (queue, circular queue, instruction table)

## Issues Encountered
- [e.g., #01 Instruction representation — class-based vs table-based]

## Decisions Made
- Language: Java (preferred option, no justification needed)
- [Add architecture / structure decisions here]

## Individual Contributions
| Student | Contribution |
|---|---|
| [Name] | |
| [Name] | |
| [Name] | |
| [Name] | |

## Work Accepted
- Initial simulator architecture
- Team responsibility allocation

## Work Carried Forward
- Week 2: CPU core implementation (registers, PC, flags, memory model)

---

# Week 1 Acceptance

**Completed:**
- Repository setup
- Architecture study
- Language selection
- Initial design

**Accepted:**
- Initial simulator architecture
- Team responsibility allocation

**Pending:**
- Detailed CPU design
- Instruction implementation

**Issues:**
- [List issue numbers, e.g., #01, #02]

**Carry Forward:**
- Week 2 CPU implementation
