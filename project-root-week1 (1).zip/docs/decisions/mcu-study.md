# Microcontroller Study Notes — Nuvoton MS51FB9AE

*(Week 1 deliverable — required by brief item 6. Written for beginners; goes into the "why" as well as the "what.")*

## What chip is this, really?
The MS51FB9AE is Nuvoton's own chip, but its CPU **core** is a licensed, enhanced **8051** (also called MCS-51) — the same instruction set and register model used in one of the most famous microcontroller families ever made. That's good news for us: 8051 architecture is extremely well documented, and our simulator gets to be a real, recognizable "mini-8051" instead of an invented toy design.

**Key real numbers** (for reference/documentation — our simulator will use much smaller, simplified sizes):
- CPU: 8-bit, 1T (1 clock cycle per instruction cycle) 8051 core, up to 24 MHz
- Program memory: 16 KB Flash (called APROM) + 4 KB LDROM (boot/ISP loader)
- Data memory: 1 KB internal SRAM
- GPIO: 18 pins
- Interrupts: 4 priority levels
- Other peripherals: multiple timers, PWM, UART x2, SPI, I²C, 12-bit ADC (not all needed for our simulator)

## 1. CPU / Register Organization
The 8051 core has a small, fixed set of registers — this is much simpler than a modern CPU:
- **Accumulator (A)** — where most arithmetic/logic results land
- **B register** — used with A for multiply/divide
- **R0–R7** — 8 general-purpose "working registers," organized into 4 *banks* of 8 (only one bank active at a time, selected by 2 bits in the flag register)
- **DPTR (Data Pointer)** — 16-bit register used to point at memory when reading/writing data tables (MS51FB9AE actually has *two* DPTRs; a simulator only needs one to start)

*Simulator plan: implement A, B, and R0–R7 as a single active bank to start. Multiple banks can be a stretch goal.*

## 2. Program Counter (PC)
- 16-bit register holding the address of the next instruction to fetch.
- Real chip can address up to 64 KB of program memory; our simulator will use a much smaller array (e.g., 256 instruction slots) since we're only implementing a subset.

## 3. Stack Pointer (SP)
- 8-bit register pointing into internal RAM.
- Unlike some other architectures, the 8051 stack **grows upward** (SP is incremented *before* a push).
- Used automatically by `CALL`/`RET` (for the return address) and explicitly by `PUSH`/`POP`.

## 4. Status / Flag Information
The 8051 keeps its flags in one register called the **PSW (Program Status Word)**:
| Bit | Flag | Meaning |
|---|---|---|
| CY | Carry | Set on arithmetic carry/borrow |
| AC | Auxiliary Carry | Carry out of the low nibble (used for BCD math) |
| RS1, RS0 | Register bank select | Chooses which R0–R7 bank is active |
| OV | Overflow | Signed arithmetic overflow |
| P | Parity | Set if A has an odd number of 1 bits |

*Simulator plan: implement Carry, Overflow, and a Zero flag (Zero isn't a native 8051 PSW bit, but many educational simulators add it for simpler branch logic — worth raising as a design decision/GitHub Issue).*

## 5. Memory Organization
Two physically separate spaces (classic "Harvard-ish" split, typical of 8051 family):
- **Program memory (Flash/APROM + LDROM)** — holds instructions; read-only during normal execution
- **Internal data memory (RAM)** — holds variables, the stack, and Special Function Registers (SFRs) for peripherals

*Simulator plan: two separate arrays — `programMemory[]` and `dataMemory[]` — instead of one shared address space.*

## 6. Stack Mechanism
- Lives inside internal RAM, at addresses above the register banks.
- `PUSH`/`POP` move a byte to/from `dataMemory[SP]`, adjusting SP.
- `CALL` pushes the return address (PC), `RET` pops it back into PC.

## 7. Instruction Categories
The full 8051 instruction set has ~111 instructions; our simulator only needs a representative subset from each category:
- **Data transfer:** `MOV`, `MOVX`, `MOVC`
- **Arithmetic:** `ADD`, `SUBB`, `INC`, `DEC`
- **Logic:** `ANL`, `ORL`, `XRL`, `CPL`
- **Control flow:** `SJMP`/`LJMP`, `JZ`, `JNZ`, `CJNE`, `DJNZ`, `CALL` (`ACALL`/`LCALL`), `RET`
- **Bit manipulation:** `SETB`, `CLR` — a distinctive 8051 feature (individual bits in certain RAM/SFR regions can be addressed directly)
- **Stack:** `PUSH`, `POP`

*This list should be finalized as a team decision and recorded as a GitHub Issue/decision — it directly defines the scope of the CPU module.*

## 8. GPIO
- Real chip: 18 pins across multiple ports, individually configurable and bit-addressable.
- Simulator plan: a small array or dictionary of pin states (e.g., 8 simulated pins), with `IN`/`OUT`-style instructions to read/write them.

## 9. Timer
- Real chip has multiple 16-bit hardware timers used for delays, PWM, and generating periodic interrupts.
- Simulator plan: one simple countdown/overflow timer that raises a flag (or triggers an interrupt) when it hits zero — this is also what drives **preemption for Round Robin scheduling**.

## 10. Interrupt Mechanism
- Real chip: 4 priority levels, vectored interrupts (timer overflow, external pins, serial port, etc.).
- Simulator plan: one interrupt vector table (even a 2–3 entry table is enough), an enable/disable flag, and a simple "jump to ISR address, save PC, return via RETI-equivalent" mechanism.

## Why this matters for our project
The brief explicitly says we don't need to implement the *complete* real processor — just enough register/memory/instruction/peripheral behavior to support instruction execution, PCB-based process management, and CPU scheduling. Because the MS51FB9AE's core is a standard 8051, we can lean on decades of existing 8051 teaching material for instruction semantics instead of inventing our own ISA from scratch.

## Open questions for the team (raise as GitHub Issues)
1. How many register banks do we actually implement — 1 or all 4?
2. Do we add a synthetic Zero flag, or derive zero-checks from the Accumulator value directly?
3. Final instruction subset — which ~15–20 instructions make the cut?
4. Instruction representation — class-based objects vs. a lookup table of functions?
