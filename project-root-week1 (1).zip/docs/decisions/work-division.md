# Team Responsibility Allocation

| Member | Primary Responsibility | Supporting Responsibility |
|---|---|---|
| Student 1 — Team Leader | CPU & Instruction Execution | Integration & GitHub |
| Student 2 | Memory & Stack | CPU support |
| Student 3 | Data Structures & Process Management | Testing |
| Student 4 | OS Scheduling & Context Switching | UI & Integration |

**Note:** Allocation may be adjusted based on team strengths, but every member must retain a clearly identifiable, meaningful technical contribution throughout the project.
