# Meeting Minutes

**Date:**
**Meeting Number:**
**Participants:**

## Agenda
1.
2.

## Discussion


## Decisions
1.
2.

## Action Items
- Student 1:
- Student 2:
- Student 3:
- Student 4:

**Next Meeting:**
